function nextPage(pageNumber) {
    document.querySelectorAll('.container').forEach(div => div.classList.remove('active'));
    document.getElementById("page" + pageNumber).classList.add("active");
}
